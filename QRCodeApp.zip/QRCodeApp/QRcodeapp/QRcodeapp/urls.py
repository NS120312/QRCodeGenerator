from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.staticfiles.views import serve
from app.views import (
    home,
    DecodeImage,
    GenerateQRCode,
    navbar,
    event_qr,
    link_qr,
    text_qr,
    contact,
    login_view,
    logout_view,
    signup_view,
    accept_invitation,
    invitation,
    capture_scan_data,
   # add_scan_report,
    decline_invitation,  # Import decline_invitation here
)

urlpatterns = [
    # Admin
    path('admin/', admin.site.urls),

    # Authentication
    path('', login_view, name='login'),  # Default root URL
    path('signup/', signup_view, name='signup'),
    path('logout/', logout_view, name='logout'),

    # Dashboard
    path('home/', home, name='home'),

    # QR Code Features
    path('decode/', DecodeImage, name='decodeimage'),
    path('api/generate-qr/', GenerateQRCode.as_view(), name='generate_qr'),
    path('generate/', GenerateQRCode.as_view(), name='generate_qrcode'),
    path('qr/event/', event_qr, name='event_qr'),
    path('qr/link/', link_qr, name='link_qr'),
    path('qr/text/', text_qr, name='text_qr'),

    # Event Invitation
    path('invitation/', invitation, name='invitation'),
    path('accept-invitation/', accept_invitation, name='accept_invitation'),

    # Navbar (if needed for some page component)
    path('navbar/', navbar, name='navbar'),
    path('navbar/invitation/', invitation, name='navbar_invitation'),

    # Favicon
    path('favicon.ico', serve, {'path': 'favicon.ico'}),

    # Capture Scan Data
    path('api/report/', capture_scan_data, name='capture_scan_data'),  # Make sure this is defined in views.py
    path('invitation/decline/', decline_invitation, name='decline_invitation'),  # Fix here
    #path('add-scan-report/', add_scan_report, name='add_scan_report'),


] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)  # For media files handling
