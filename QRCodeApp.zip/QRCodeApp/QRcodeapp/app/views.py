from django.shortcuts import render
import qrcode
from django.core.files.base import ContentFile
import qrcode.constants
from app.models import GenerateImage , DecodeImage
from PIL import Image
from pyzbar.pyzbar import decode
import io
from qrcode.image.pil import PilImage
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import render
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login
from .forms import SignUpForm
from django.http import JsonResponse
import json


# Create your views here.



def generate_qr_code(data):
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(data)
    qr.make(fit=True) 

    img = qr.make_image(fill_color="black",black_color="white")
    return img
def home(request):
    if request.method == 'POST':
        data = request.POST.get('myurl')
        img = generate_qr_code(data)

        image_io = io.BytesIO()
        img.save(image_io,format="PNG")

        image_file = ContentFile(image_io.getvalue(),name='my_qr_code.png')

        qr_image = GenerateImage.objects.create(imag=image_file)

        context = {'img':qr_image}
        return render(request,'index.html', context)

    return render(request,'index.html')

def decode_qr_code(image_path):
    image = Image.open(image_path)
    decode_object = decode(image)
    if decode_object:
        return decode_object[0].data.decode('utf-8')
    else:
        return None
    
def decodeimage(request):
    context = {'data':None}
    if request.method == 'POST':
            myimag = request.FILES.get('myimg')
            img = DecodeImage(imag=myimag)
            img.save()
            qr_code_path = img.imag.path
            decode_data = decode_qr_code(qr_code_path)
            context['data'] = decode_data


def decode_view(request):
    try:
        decode_image = DecodeImage.objects.get(id=request.GET.get('id'))
        # Process the object here
    except DecodeImage.DoesNotExist:
        decode_image = None
        print(f"Request: {request}")
          
        return render(request, 'decode_template.html',{'decode_image': decode_image})
    return render(request, 'decode.html')
    

class GenerateQRCode(APIView):
    def post(self, request):
        qr_type = request.data.get("qr_type", "Text")
        data = request.data.get("data", "")
        color = request.data.get("color", "#000000")
        background = request.data.get("background", "#FFFFFF")

        # Generate QR Code
        qr = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_H)
        qr.add_data(data)
        qr.make(fit=True)
        img = qr.make_image(fill_color=color, back_color=background)
        
        # Save QR Code
        img_path = f"qrcodes/{qr_type}_{int(time.time())}.png" # type: ignore
        img.save(img_path)

        # Respond with QR Code URL
        return Response({"qr_image_url": img_path}, status=status.HTTP_201_CREATED)

def home(request):
    return render(request, 'home.html')

def event_qr(request):
    # Logic for event QR code generation
    return render(request, 'event_qr.html')

def link_qr(request):
    # Logic for link QR code generation
    return render(request, 'link_qr.html')

def text_qr(request):
    # Logic for text QR code generation
    return render(request, 'text_qr.html')

def contact(request):
    return render(request, 'contact.html')

def navbar(request):
    # Logic for rendering the navbar
    return render(request, 'navbar.html')

def login_view(request):
    return render(request, 'login.html')
from django.shortcuts import render, redirect
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, logout

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('navbar')  # Replace 'home' with your desired URL
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('login')  # Redirect to login after logout

from django.shortcuts import render

from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import messages

def signup_view(request):
    if request.method == "POST":
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']
        
        if password != confirm_password:
            messages.error(request, "Passwords do not match!")
            return render(request, 'signup.html')
        
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists!")
            return render(request, 'signup.html')
        
        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already exists!")
            return render(request, 'signup.html')
        
        # Create user and save to database
        user = User.objects.create_user(username=username, email=email, password=password)
        user.save()
        messages.success(request, "Account created successfully! Please log in.")
        return redirect('login')
    return render(request, 'signup.html') 
   

def event_details(request):
    event_name = request.GET.get('name', 'No Event Name')
    event_date = request.GET.get('date', 'N/A')
    event_time = request.GET.get('time', 'N/A')
    event_location = request.GET.get('location', 'N/A')
    event_description = request.GET.get('description', 'No description available')
    return render(request, 'event_details.html', {
        'event_name': event_name,
        'event_date': event_date,
        'event_time': event_time,
        'event_location': event_location,
        'event_description': event_description,
    })

    
from django.shortcuts import render
from django.http import HttpResponse

def invitation(request):
    print('printiiiiiiiiiiiiiing',request.GET)
    event_name = request.GET.get('name', 'Unknown Event')
    event_date = request.GET.get('date', 'Unknown Date')
    event_time = request.GET.get('time', 'Unknown Time')
    event_location = request.GET.get('location', 'Unknown Location')
    event_description = request.GET.get('description', 'No Description Provided')

    context = {
        'event_name': event_name,
        'event_date': event_date,
        'event_time': event_time,
        'event_location': event_location,
        'event_description': event_description,
    }
    return render(request, 'invitation.html', context)
from django.http import HttpResponse

def accept_invitation(request):
    return HttpResponse("Thank you for accepting the invitation!")
def accept_invitation(request):
    if request.method == 'POST':
        # Process the acceptance (e.g., save data, send an email, etc.)
        return HttpResponse("You have accepted the invitation!")
    return HttpResponse("Invalid request.")
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from .models import ScanReport

@csrf_exempt
def capture_scan_data(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        ScanReport.objects.create(
            event_name=data.get('eventName'),
            event_date=data.get('eventDate'),
            event_time=data.get('eventTime'),
            event_location=data.get('eventLocation'),
            event_description=data.get('eventDescription'),
            response=data.get('response'),
        )
        return JsonResponse({'message': 'Scan data captured successfully!'}, status=201)

    return JsonResponse({'error': 'Invalid request'}, status=400)
def decline_invitation(request):
    # Your decline invitation logic here
    return HttpResponse('Invitation Declined')