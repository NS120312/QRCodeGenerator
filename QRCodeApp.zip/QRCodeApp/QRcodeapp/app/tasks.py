from django.core.mail import send_mail
from .models import ScanReport

def send_admin_report():
    # Fetch scan data
    scan_data = ScanReport.objects.all()

    # Prepare email content
    message = "Here is the report of users who scanned the QR code:\n\n"
    for scan in scan_data:
        message += f"Event: {scan.event_name}\n"
        message += f"Date: {scan.event_date}\n"
        message += f"Time: {scan.event_time}\n"
        message += f"Location: {scan.event_location}\n"
        message += f"Response: {scan.response}\n"
        message += f"Timestamp: {scan.timestamp}\n\n"

    # Send the email
    send_mail(
        subject="QR Code Scan Report",
        message=message,
        from_email="admin@example.com",  # Replace with your email
        recipient_list=["admin@example.com"],  # Replace with admin's email
    )
