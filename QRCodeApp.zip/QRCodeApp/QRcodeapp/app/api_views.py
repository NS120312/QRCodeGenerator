from rest_framework.views import APIView
from rest_framework.response import Response
from .models import QRCode
import qrcode

class GenerateQRCode(APIView):
    def post(self, request):
        data = request.data.get("text")
        qr = qrcode.make(data)
        # Save the QR code to the media folder
        qr.save(f"media/{data}.png")
        return Response({"message": "QR Code generated", "url": f"/media/{data}.png"})
