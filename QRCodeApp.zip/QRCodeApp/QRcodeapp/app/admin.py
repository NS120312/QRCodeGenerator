from django.contrib import admin
from app.models import GenerateImage, DecodeImage
from app.models import QRCode

@admin.register(GenerateImage)
class GenerateImageAdmin(admin.ModelAdmin):
    list_display = ('id', 'imag')  # Replace 'imag' if the field is named differently

@admin.register(DecodeImage)
class DecodeImageAdmin(admin.ModelAdmin):
    list_display = ('id', 'image')  # Replace 'imag' if the field is named differently

class QRCodeAdmin(admin.ModelAdmin):
    list_display = ('name', 'created_at')  # Update with the actual fields
