from django.db import models

# Create your models here.

class GenerateImage(models.Model):
    imag= models.ImageField(upload_to='media')



class DecodeImage(models.Model):
    image= models.ImageField(upload_to='media')
from django.db import models

class ScanReport(models.Model):
    event_name = models.CharField(max_length=200)
    event_date = models.DateField()
    event_time = models.TimeField()
    event_location = models.CharField(max_length=500)
    event_description = models.TextField()
    response = models.CharField(max_length=10)  # Accepted/Declined
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.event_name} - {self.response}"


class QRCode(models.Model):
   qr_type = models.CharField(max_length=50)  # e.g., "URL", "Text", "WiFi"
   data = models.TextField()  # Content of the QR code
   image = models.ImageField(upload_to="qrcodes/")
   color = models.CharField(max_length=7, default="#000000")  # QR color (hex)
   background = models.CharField(max_length=7, default="#FFFFFF")  # Background color
   created_at = models.DateTimeField(auto_now_add=True)

def __str__(self):
        return f"{self.qr_type} - {self.data}"
